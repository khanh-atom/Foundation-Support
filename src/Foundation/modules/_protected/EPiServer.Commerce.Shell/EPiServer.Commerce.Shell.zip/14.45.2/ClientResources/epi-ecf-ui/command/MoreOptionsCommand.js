//>>built
define("epi-ecf-ui/command/MoreOptionsCommand",["dojo/_base/declare","epi/shell/command/_Command"],function(_1,_2){return _1([_2],{canExecute:true,_execute:function(){}});});