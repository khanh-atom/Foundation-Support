//>>built
define("epi-ecf-ui/command/LanguageSelector",["dojo/_base/declare","epi/shell/command/_Command"],function(_1,_2){return _1([_2],{isAvailable:true,canExecute:true,});});