define("epi-forms/contentediting/editors/DependAllowMultiSelectAndFeedEditor", [// dojo
"dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", "dojo/dom-style", "dojo/when", // epi
"epi/dependency", "epi-cms/contentediting/command/Editing", // epi-forms
"epi-forms/contentediting/editors/OptionListEditor", "epi-forms/ModuleSettings"], function ( // dojo
array, declare, lang, domStyle, when, // epi
dependency, EditingCommands, // epi-forms,
OptionListEditor, ModuleSettings) {
  // module:
  //      epi-forms/contentediting/editors/DependAllowMultiSelectEditor
  // summary:
  //
  // tags:
  //      public
  return declare([OptionListEditor], {
    _store: null,
    _contentViewModel: null,
    _feedSelection: null,
    _allowMultiSelect: null,
    _allowMultiSelectPropertyName: "allowMultiSelect",
    _feedPropertyName: "feed",
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    postCreate: function postCreate() {
      var _this$_contentViewMod;

      // tags:
      //      protected, extensions
      var registry = dependency.resolve("epi.storeregistry");
      this._store = registry.get("epi.cms.content.light"); // this editor depend on [Allow Multiple Select] property,
      // if [Allow Multiple Select] property is set to true then allow multi selection on this editor,
      // otherwise allow single selection

      this.isMultiSelect = (_this$_contentViewMod = this._contentViewModel) === null || _this$_contentViewMod === void 0 ? void 0 : _this$_contentViewMod.getProperty(this._allowMultiSelectPropertyName);
      this.connect(this._feedSelection, "onFeedValueChange", lang.hitch(this, function (propertyName, value) {
        this._setOptionItemsEditorDisplay(value == ModuleSettings.useManualInput);
      }));
      this.connect(this._allowMultiSelect, "onFeedValueChange", lang.hitch(this, function (propertyName, value) {
        this.isMultiSelect = value; // reset checked items if the property change from true to false

        if (!value) {
          array.forEach(this.model.get("items"), function (existingItem, i) {
            existingItem.checked = false;
            this.model.saveItem(existingItem, i);
          }, this);
        }
      }));
      this.inherited(arguments);
    },
    startup: function startup() {
      var _this$_contentViewMod2;

      this.inherited(arguments);
      var feedValue = (_this$_contentViewMod2 = this._contentViewModel) === null || _this$_contentViewMod2 === void 0 ? void 0 : _this$_contentViewMod2.getProperty(this._feedPropertyName);

      this._setOptionItemsEditorDisplay(feedValue == ModuleSettings.useManualInput);
    },
    // =======================================================================
    // Private stubs
    // =======================================================================
    _setOptionItemsEditorDisplay: function _setOptionItemsEditorDisplay(show) {
      // summary:
      //      show/hide OptionItems editor.
      // tags:
      //      private
      // show/hide whole field item which contain this editor
      domStyle.set(this.domNode.parentNode, "display", show ? "" : "none");
    },
    _getGridDefinition: function _getGridDefinition() {
      // summary:
      //      Returns grid's columns definition.
      // tags:
      //      override
      var columns = this.inherited(arguments); // display name of the image instead of ID

      lang.mixin(columns.source, {
        renderCell: lang.hitch(this, function (item, value, node, options) {
          if (!item.source) {
            return;
          }

          when(this._store.get(item.source), lang.hitch(this, function (content) {
            node.innerHTML = content.name;
          }));
        })
      });
      return columns;
    }
  });
});