define("epi-forms/widget/ChoiceItemWithSelection", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/when", // epi-addons
"epi-forms/widget/_ChoiceItemWith", "epi-forms/widget/_SelectionMixin"], function ( // dojo
declare, lang, when, // epi-addons
_ChoiceItemWith, _SelectionMixin) {
  // module:
  //      epi-forms/widget/ChoiceItemWithSelection
  // summary:
  //      Radio button widget included clickable label and drop-down button.
  //      'this.extendedWidgetType' should be:
  //      - 'epi-cms/contentediting/editors/SelectionEditor' or,
  //      - 'epi-cms/contentediting/editors/SelectionEditor''s concrete type
  // tags:
  //      public
  return declare([_ChoiceItemWith], {
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    buildRendering: function buildRendering() {
      this.inherited(arguments);

      this._setupExtendedWidget();
    },
    isValid: function isValid() {
      // summary:
      //      Return the current value is valid or not depend on children widget.
      // tags:
      //      public
      if (this._selector.get("checked")) {
        return !!(this._extendedWidget && this._extendedWidget.get("value"));
      }

      return true;
    },
    validate: function validate() {
      // summary:
      //      Validate this widget value.
      // tags:
      //      public
      if (this._selector.get("checked") && this._extendedWidget && this._extendedWidget._filteringSelectDefer) {
        this._extendedWidget._filteringSelectDefer.then(lang.hitch(this, function (filteringSelect) {
          if (!filteringSelect.get("value")) {
            filteringSelect.focus();
            filteringSelect.set("message", filteringSelect.getErrorMessage(true));
          } else {
            filteringSelect.onBlur();
          }
        }));
      }

      return this.isValid();
    },
    // =======================================================================
    // Protected stubs
    // =======================================================================
    // =======================================================================
    // Private stubs
    // =======================================================================
    _setupExtendedWidget: function _setupExtendedWidget() {
      // summary:
      //      Decorates layout for this widget.
      // tags:
      //      private
      if (!this.model) {
        when(this.getInstanceFromType(this.editorModelType), lang.hitch(this, this._bindDataForExtendedWidget));
      } else {
        this._bindDataForExtendedWidget(this.model);
      }
    },
    _bindDataForExtendedWidget: function _bindDataForExtendedWidget(model) {
      // summary:
      //      Bind data for extended widget.
      // model: [Object]
      //      View model for created drop-down button.
      // tags:
      //      private
      when(model.getItems(this.searchConditions), lang.hitch(this, function (items) {
        when(this._getExtendedWidget(), lang.hitch(this, function (extendedWidget) {
          if (!extendedWidget) {
            return;
          }

          declare.safeMixin(extendedWidget, _SelectionMixin);
          extendedWidget.set("selections", this._getSelectionsData(items));
          this.set("extendedWidgetValue", this.item);
          this.own(extendedWidget.on("change", lang.hitch(this, this._updateSelectorValue)));
        }));
      }));
    },
    _getSelectionsData: function _getSelectionsData(
    /*Array*/
    items) {
      // summary:
      //      Gets selections data from given items array.
      // items: [Array]
      //      Item data collection.
      // tags:
      //      private
      var selections = [];

      if (!(items instanceof Array) || items.length === 0) {
        return selections;
      }

      var selectedValue = this.selectorValue.split(this._recordFieldSeparator)[1];
      var i = 0,
          totalItems = items.length,
          item = null;

      for (; i < totalItems; i++) {
        item = items[i];

        if (!item) {
          continue;
        } // only add selected item of current field and items have not been selected by other fields


        var selectedFields = this.searchConditions ? this.searchConditions.selectedFields : null;

        if (!selectedFields || item.value === selectedValue || selectedFields.indexOf(item.value) < 0) {
          selections.push({
            text: item.value,
            value: item.key
          });
        }
      }

      return selections;
    }
  });
});